module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ success: false, message: "Método não permitido." });

  const { name = "", email = "", company = "" } = req.body || {};
  const cleanName = String(name).trim().slice(0, 80);
  const cleanEmail = String(email).trim().toLowerCase().slice(0, 160);
  const honeypot = String(company).trim();

  if (honeypot) return res.status(201).json({ success: true });
  if (cleanName.length < 2) return res.status(400).json({ success: false, message: "Informe seu nome para receber o guia." });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) return res.status(400).json({ success: false, message: "Digite um e-mail válido para receber o guia." });

  const apiKey = process.env.BREVO_API_KEY;
  const listId = Number(process.env.BREVO_LIST_ID || 5);
  if (!apiKey) return res.status(500).json({ success: false, message: "A integração com a Brevo ainda não foi configurada." });

  const parts = cleanName.split(/\s+/);
  const firstName = parts.shift() || cleanName;
  const lastName = parts.join(" ");
  const attributes = { FIRSTNAME: firstName };
  if (lastName) attributes.LASTNAME = lastName;

  try {
    const brevo = await fetch("https://api.brevo.com/v3/contacts", {
      method: "POST",
      headers: { "api-key": apiKey, "content-type": "application/json", accept: "application/json" },
      body: JSON.stringify({ email: cleanEmail, attributes, listIds: [listId], updateEnabled: true })
    });
    if (!brevo.ok) {
      const detail = await brevo.text();
      console.error("Brevo error", brevo.status, detail);
      return res.status(502).json({ success: false, message: "Não foi possível cadastrar seu e-mail agora. Tente novamente." });
    }
    return res.status(201).json({ success: true });
  } catch (error) {
    console.error("Brevo request failed", error);
    return res.status(502).json({ success: false, message: "Não foi possível conectar à Brevo agora. Tente novamente." });
  }
};
