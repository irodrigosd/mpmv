(() => {
  "use strict";
  const root = document.querySelector(".mpmv-site");
  if (!root) return;
  const downloadUrl = "/assets/downloads/guia-pratico-persuasao-pra-vender-todo-santo-dia.pdf";
  const downloadName = "[Guia Prático] Persuasão Pra Vender Todo Santo Dia.pdf";
  const cookieKey = "mpmv-cookie-consent-v2";
  const cookieBanner = document.getElementById("mpmv-cookie-banner");
  const backdrop = document.getElementById("mpmv-modal-backdrop");
  const modal = backdrop?.querySelector(".mpmv-modal");
  const openButton = document.getElementById("mpmv-open-modal");
  const closeButton = document.getElementById("mpmv-close-modal");
  const form = document.getElementById("mpmv-lead-form");
  const firstInput = document.getElementById("mpmv-name");
  const formView = document.getElementById("mpmv-form-view");
  const successView = document.getElementById("mpmv-success-view");
  const submitButton = document.getElementById("mpmv-submit");
  const errorBox = document.getElementById("mpmv-form-error");
  let previousOverflow = "";

  const readStorage = (key) => { try { return localStorage.getItem(key); } catch { return null; } };
  const writeStorage = (key, value) => { try { localStorage.setItem(key, value); } catch {} };
  if (cookieBanner && readStorage(cookieKey) === null) cookieBanner.classList.remove("mpmv-hidden");
  root.querySelectorAll("[data-mpmv-cookie]").forEach((button) => button.addEventListener("click", () => {
    writeStorage(cookieKey, button.dataset.mpmvCookie || "accepted");
    cookieBanner?.classList.add("mpmv-hidden");
  }));

  const clearError = () => { if (errorBox) { errorBox.textContent = ""; errorBox.classList.add("mpmv-hidden"); } };
  const showError = (message) => { if (errorBox) { errorBox.textContent = message; errorBox.classList.remove("mpmv-hidden"); } };
  const openModal = () => {
    if (!backdrop) return;
    clearError(); formView?.classList.remove("mpmv-hidden"); successView?.classList.add("mpmv-hidden");
    if (submitButton) { submitButton.disabled = false; submitButton.textContent = "RECEBER O GUIA AGORA"; }
    previousOverflow = document.body.style.overflow; document.body.style.overflow = "hidden";
    backdrop.classList.remove("mpmv-hidden"); backdrop.setAttribute("aria-hidden", "false");
    setTimeout(() => firstInput?.focus(), 80);
  };
  const closeModal = () => {
    if (!backdrop) return;
    backdrop.classList.add("mpmv-hidden"); backdrop.setAttribute("aria-hidden", "true");
    document.body.style.overflow = previousOverflow; setTimeout(() => openButton?.focus(), 0);
  };
  openButton?.addEventListener("click", openModal); closeButton?.addEventListener("click", closeModal);
  backdrop?.addEventListener("mousedown", (event) => { if (event.target === backdrop) closeModal(); });
  document.addEventListener("keydown", (event) => {
    if (!backdrop || backdrop.classList.contains("mpmv-hidden")) return;
    if (event.key === "Escape") return closeModal();
    if (event.key !== "Tab" || !modal) return;
    const focusable = Array.from(modal.querySelectorAll('button:not([disabled]), a[href], input:not([disabled]):not([tabindex="-1"])')).filter((el) => !el.closest(".mpmv-hidden"));
    if (!focusable.length) return;
    const first = focusable[0], last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  });

  const startDownload = () => {
    const link = document.createElement("a"); link.href = downloadUrl; link.download = downloadName;
    document.body.appendChild(link); link.click(); link.remove();
  };
  form?.addEventListener("submit", async (event) => {
    event.preventDefault(); if (!form.reportValidity()) return; clearError();
    if (submitButton) { submitButton.disabled = true; submitButton.textContent = "LIBERANDO SEU GUIA..."; }
    const data = Object.fromEntries(new FormData(form).entries());
    try {
      const response = await fetch("/api/lead", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
      const payload = await response.json();
      if (!response.ok || !payload.success) throw new Error(payload.message || "Não foi possível liberar o guia.");
      formView?.classList.add("mpmv-hidden"); successView?.classList.remove("mpmv-hidden"); startDownload();
    } catch (error) {
      showError(error instanceof Error ? error.message : "Tente novamente em alguns instantes.");
      if (submitButton) { submitButton.disabled = false; submitButton.textContent = "RECEBER O GUIA AGORA"; }
    }
  });
})();
